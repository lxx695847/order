const { src, dest, series, parallel, watch } = require('gulp');

const uglify = require('gulp-uglify');
// 压缩css
const cleanCSS = require('gulp-clean-css');

const sass = require('gulp-sass')(require('sass'));
const rename = require('gulp-rename');
const del = require('delete');
// gulp judgment
const gulpif = require('gulp-if');

// Refresh the browser in real time
const browserSync = require('browser-sync').create();
const reload = browserSync.reload;

const production = process.env.NODE_ENV === 'production' ? true : false;


// file handler paths
const paths = {
  // static resources,contains index.html, fonts and images,and extension plugins dependency
  html: ['./*.html'],
  images: ['./image/**'],
  imagesM: ['./image-m/**'],
  js: ['./js/*.js'],
  css: ['./css/*.css'],
  scss: ['./scss/*.scss'],
  plugins: ['./plugins/**'],

  destHtml: ['./dist'],
  destImages: ['./dist/image'],
  destImagesM: ['./dist/image-m'],
  destJs: ['./dist/js'],
  destCss: ['./dist/css'],
  destScss: ['./dist/css'],
  destplugins: ['./dist/plugins'],

  dist: './dist',
}


function clean() {
  return del(['dist']);
}

// Static server
function serve(done) {
  browserSync.init({
      server: {
        baseDir: paths.dist,
        index: "zh.html"
      },
      ghostMode: false, //默认true，滚动和表单在任何设备上输入将被镜像到所有设备里，会影响本地的协同编辑消息，故关闭
  }, done)
}

function watcher(done) {
  // 当内容有变化时重新编译
  watch(paths.js,{ delay: 500 }, series(pluginsJs, reloadBrowser));
  watch(paths.css,{ delay: 500 }, series(pluginsCss, reloadBrowser));
  watch(paths.scss,{ delay: 500 }, series(pluginsScss, reloadBrowser));

  // 当文件有变化时重新copy文件
  watch(paths.html,{ delay: 500 }, series(copyHtml, reloadBrowser));
  watch(paths.images,{ delay: 500 }, series(copyImages, reloadBrowser));
  watch(paths.imagesM,{ delay: 500 }, series(copyImagesM, reloadBrowser));
  watch(paths.plugins,{ delay: 500 }, series(copyPlugins, reloadBrowser));
  done();
}
// Refresh browser
function reloadBrowser(done) {
  reload();
  done();
}

function pluginsJs () {
  return src(paths.js)
    .pipe(gulpif(production, uglify()))
    .pipe(dest(paths.destJs));
}

function pluginsCss(){
  return src(paths.css)
      .pipe(gulpif(production, cleanCSS()))
      .pipe(dest(paths.destCss));
}

function pluginsScss(){
  return src(paths.scss)
      .pipe(sass().on('error', sass.logError))
      .pipe(gulpif(production, cleanCSS()))
      .pipe(dest(paths.destScss));
}

// Copy static resources
function copyHtml(){
  return src(paths.html)
      .pipe(dest(paths.destHtml));
}
function copyImages(){
  return src(paths.images)
      .pipe(dest(paths.destImages));
}

function copyImagesM(){
  return src(paths.imagesM)
      .pipe(dest(paths.destImagesM));
}

function copyPlugins(){
  return src(paths.plugins)
      .pipe(dest(paths.destplugins));
}



const dev = series(clean, parallel(copyHtml, copyImages, copyImagesM, copyPlugins, pluginsJs, pluginsCss), pluginsScss, watcher, serve);

const build = series(clean, parallel(copyHtml, copyImages, copyImagesM, copyPlugins, pluginsJs, pluginsCss), pluginsScss);

exports.dev = dev;
exports.build = build;
exports.default = dev;