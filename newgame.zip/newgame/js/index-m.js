/*
 * @Description: 内容描述
 * @Author: sunshiyong
 * @Date: 2021-12-26 23:35:37
 * @LastEditTime: 2022-01-05 21:18:27
 */

var swiper = new Swiper('.features-box .swiper-container', {
  watchSlidesProgress: true,
  slidesPerView: 'auto',
  centeredSlides: true,
  loop: true,
  loopedSlides: 5,
  autoplay: false,
  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev',
  },
  pagination: {
    el: '.swiper-pagination',
  },
  on: {
    progress: function(progress) {
      for (i = 0; i < this.slides.length; i++) {
        var slide = this.slides.eq(i);
        var slideProgress = this.slides[i].progress;
        modify = 1;
        if (Math.abs(slideProgress) > 1) {
          modify = (Math.abs(slideProgress) - 1) * 0.3 + 1;
        }
        translate = slideProgress * modify * 207 + 'px';
        scale = 1 - Math.abs(slideProgress) / 5;
        zIndex = 999 - Math.abs(Math.round(10 * slideProgress));
        slide.transform('translateX(' + translate + ') scale(' + scale + ')');
        slide.css('zIndex', zIndex);
        slide.css('opacity', 1);
        if (Math.abs(slideProgress) > 3) {
          slide.css('opacity', 0);
        }
      }
    },
    setTransition: function(transition) {
      for (var i = 0; i < this.slides.length; i++) {
        var slide = this.slides.eq(i)
        slide.transition(transition);
      }

    }
  }
});


var a=1;
  setInterval(function () {
    a+=1;
    if (a==360){
        a=1
    }
    $(".aoc").css("transform","rotate("+a+"deg)");
},30);

var video = document.getElementById('video');
$("#video_play").click(function () {
  $(".aoc").fadeOut();
  $(this).fadeOut();
  if(video.paused){  //如果已暂停则播放
    video.play(); //播放控制
  }else{ // 已播放点击则暂停
    video.pause(); //暂停控制
  }
  $("#video").attr("controls", "")
  $("#video").attr("controlslist", "nodownload  noremoteplayback")
});

$(".play_box").click(function(){
  $(".mask_video").css("display","block")
})

$("#lang-img").click(function(){
  if ($("#lang-nav").css("display") == "none") {
    $(".lang-nav").fadeIn();
  } else {
    $(".lang-nav").fadeOut();
  }
})

if (isWeixn()){
  $("#banner-video").attr("poster", "/image-m/kv.jpg")
}