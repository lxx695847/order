/*
 * @Description: 内容描述
 * @Author: sunshiyong
 * @Date: 2021-12-26 23:35:37
 * @LastEditTime: 2021-12-29 21:54:57
 */

$("#play").click(function(){
  $('.mask_video,.video_con').fadeIn();
  document.getElementById('video_con').src = $(this).attr('data-src');
  document.getElementById('video_con').play();
})
$("body .mask_video").click(function(){
  $('.mask_video,.video_con').fadeOut();
  document.getElementById('video_con').src = '';
  document.getElementById('video_con').pause();
})

var getAccept=getCookie('cookie_accpet0911')
if(!getAccept){
	$('.cookie-box').fadeIn();
}else{
	$('.cookie-box').fadeOut();
}
$('.cookie-agree').on('click',function(){
	setCookie('cookie_accpet0911','true')
	$('.cookie-box').fadeOut();
})
$('.cookie-agree-x').on('click',function(){
  $('.cookie-box').fadeOut();
})


var a=1;
setInterval(function () {
   a+=1;
   if (a==360){
      a=1
   }
   $(".aoc").css("transform","rotate("+a+"deg)");
},27);

